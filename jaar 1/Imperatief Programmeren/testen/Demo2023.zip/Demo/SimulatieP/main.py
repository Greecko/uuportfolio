from SimulatieP import Simulatie

Simulatie().mainloop()