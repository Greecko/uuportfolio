from LetterTellerP import LetterTeller

LetterTeller().mainloop()