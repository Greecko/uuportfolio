print("Wat is je naam? ", end="")
naam = input()
print(f"Hallo {naam}!")
print(f"Je naam heeft {len(naam)} letters.")
