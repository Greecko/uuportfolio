using System.Drawing;
using System.Windows.Forms;

class $projectname$ : Form
{
    public $projectname$()
    {
        this.Text = "$projectname$";
        this.BackColor = Color.LightYellow;
        this.ClientSize = new Size(200, 100);
    }
}
