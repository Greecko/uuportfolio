﻿using System;
using System.Windows.Forms;

class Program
{
    [STAThreadAttribute]
    public static void Main()
    {
        Application.Run(new $projectname$());
    }
}
