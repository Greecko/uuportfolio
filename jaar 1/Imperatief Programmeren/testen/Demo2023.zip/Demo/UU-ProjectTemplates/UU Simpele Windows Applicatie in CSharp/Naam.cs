using System.Windows.Forms;
using System.Drawing;

Form scherm = new Form();
scherm.Text = "$projectname$";
scherm.BackColor = Color.LightYellow;
scherm.ClientSize = new Size(200, 100);
Application.Run(scherm);