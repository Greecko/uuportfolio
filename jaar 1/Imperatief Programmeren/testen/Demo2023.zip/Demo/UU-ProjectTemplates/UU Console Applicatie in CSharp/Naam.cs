using System;

Console.Write("Wat is je naam? ");
string naam = Console.ReadLine();
Console.WriteLine($"Hallo {naam}!");