from tkinter import Frame

class $projectname$(Frame):
    def __init__(self):
        super().__init__()
        self.master.title("$projectname$")
        self.configure(background="lightblue")
        self.configure(width=200, height=100)
        self.pack()