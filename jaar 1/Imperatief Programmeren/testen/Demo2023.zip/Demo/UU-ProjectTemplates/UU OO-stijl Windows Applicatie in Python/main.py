from $projectname$ import $projectname$

$projectname$().mainloop()