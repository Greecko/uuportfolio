from TaalherkenningP import TaalherkenningP

TaalherkenningP().mainloop()