﻿using System.Windows.Forms;

class Program
{
    static void Main()
    {
        Application.Run(new BitmapEditor());
    }
}