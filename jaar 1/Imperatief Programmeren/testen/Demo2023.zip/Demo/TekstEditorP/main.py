from TekstEditorP import TekstEditorP

TekstEditorP().mainloop()