from BitmapEditorP import BitmapEditorP

BitmapEditorP().mainloop()