using System.Windows.Forms;

static class Program
{
    static void Main()
    {
        Application.Run(new RouteZoeker());
    }
}