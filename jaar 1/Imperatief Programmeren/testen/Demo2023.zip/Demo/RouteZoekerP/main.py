from RouteZoekerP import RouteZoekerP

RouteZoekerP().mainloop()