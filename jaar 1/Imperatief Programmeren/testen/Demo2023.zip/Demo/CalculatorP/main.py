from CalculatorP import CalculatorP

CalculatorP().mainloop()