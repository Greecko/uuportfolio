from SchetsEditorP import SchetsEditorP

SchetsEditorP().mainloop()